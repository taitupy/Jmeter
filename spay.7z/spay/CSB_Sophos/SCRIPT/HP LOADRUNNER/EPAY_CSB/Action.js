//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//" Script Title       : 
//"                      
//" Script Date        : Thu Jun 23 15:32:08 2022
//"                       
//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

function Action()
{
	
	web.setSocketsOption('SSL_VERSION', 'TLS1.2');
	
	lr.saveString(uuidv4(),'REQUESTID');
	
	var bodyEwallet = lr.evalString(
	`{
		  "Data": "+hBSEcSyz8dKDT1ioUPJXUGKj8BhIEtOy7xxEfldvszY52aTF72odtKUYEhQzPL8Ak7bcm/0eknubDnS3TmcYqL80/udAP0aA+D46rgc2ojCDefCbcnBYCbxOaEL4IhH6Ram/mdA938l3WdUWGandrH5vTRtpnRU0o2w99RouPhdFTMkDZZn6fDhsNN60eiXCIQ/rjSYLU4RzHgcb4wfNA9dNcSImmPqrS8UPl5DCWeBLLfCxsi4ysPIDx7j3l0t30XDY7XjAwWCns/5JgWNK2MxowS9JLK5ExO2KijzfxshPB7UCGfizi49Ut32gS6IJbMWQX7Sc13zN/s8NSSklxsZvFoRTFW2nRUzDisWf5eDXizaFxSkAQITFshcfIAz97t463skE9lUuN4JHTNqXTGJS5llXeZ6n9Z8xRBB6DJs00MngnWPHUXcL8kTA+RHQxvj3W5sHLmym6yw1dV2GueFGnrxWtUSyTQPmsM2Jz+Bf9c2AqC+RnHQXsVUuM1mnp/fJJmTzoLlFNBgQQ+YWmiUsg+4r1rKKMGWZ6jEKAfnyQqch19Ao/eKI5jo0CC8CgmXxYgZ5CZWbn9fRqk3tsXnSX+RJJXXB79wzUq7p3y5BlV4wpNFyxmVzBD0M0FykH1n+X23fy6Yrpul6s5dWDnzRKGa2XJii6FptvEvV976jVdJBvYtsCo80/mMXW/qgOHQ3J36TyWb7u4CAa9ASQ7lr7pvXFo8XUy3oqbAH2G2Oz9yJMth8RK7FUlNetAt9TO3NHDN4eNEp+7zDygLHNK4BeCZAsAyyPPNkEwMeme0sRNkYF9fSgCXWyZ9dL/pSFzchewf19Pp2EsBd1YK6UMVDHvXxJCzBo+uM+2v6/zzB4BgKZDWk8v4lVp98sluFyYymwLfKgdyS4048zfbe8nsHim19ezqnexWinHSlNomloKXnXQPxOmAsj3ZyRFF",
		  "FunctionName": "eWalletmPassVerification",
		  "RequestDateTime": "2022-06-24T09:14:12Z",
		  "RequestID": "{REQUESTID}"
	}`);
	
	
	lr.message('request : ' + bodyEwallet)
	lr.message(lr.evalString('REQUESTID : {REQUESTID}'));
		
	getResponeStatusCode();
	
	lr.startTransaction('01_Ewallet');
	
	web.regSaveParamRegexp(
		{
			paramName: "responseBody",
			regExp: '(?s).+',
			group: 0,
			notFound: "warning",
			scope: "body"
		}
	);
	
	
	var authen_user = 'd996c2fe-4fbd-4142-8392-10f1a5a27937';
	var authen_password = 'ad0037a087702083';
	var authen_host = '172.20.17.11:80';
	
//	web.setUser(authen_user,authen_password,authen_host);
	
	
	web.addHeader("Authorization","Basic ZDk5NmMyZmUtNGZiZC00MTQyLTgzOTItMTBmMWE1YTI3OTM3OmFkMDAzN2EwODc3MDIwODM=");
	web.addHeader("Signature",'BdbWj4p2t6QtYw/+06xX5pm3L+mXY7xXe0arTRrekTJAl/HaKhzAU6Y63K7fzFj0odOTpFdsvOVzeeTWNSevzSKhF2uuSlUnNIVOq2PylY5NpoWzu25pMRRCj0xT0ik6unVLOPTiNA/BsprADHolwT0KTvlojP+jrXmtIOHVL78d2qV2szNXzliu2UwpIQh1nI9q1x6esMIfCdZdwDi6iy49qLgu6S998pn1DD1HhsjWVsNANex9sX2/zyQyY5DTi6eD+NqdFvsinQF1hCJm/gMvPT1wtM5BelENLzCLSGERCVm3HJgzOLDgoImNenC1t11XPnBMZ0fyf7KFGxk7gA==');
	web.addHeader("Content-Type","application/json");
	web.addHeader("Accept","*/*");
	web.addHeader("Connection","keep-alive");
	
	
	web.regSaveParamRegexp(
		{
			paramName: "checkResponse",
			regExp: '"RespCode": "(.+?)"',
			group: 0,
			notFound: "warning",
			scope: "body"
		}
	);
	
	web.customRequest(
		{
			name: 'ewallet',
			url: 'http://172.20.17.11/PreprodCSB/ewallet',
			method: 'POST',
			encType: 'application/json',
			body: bodyEwallet			
		}
	);	
	
	lr.message(lr.evalString('{responseBody}'));
	
	if (lr.evalString('{checkResponse}') != "00")
	{
		
		lr.message(lr.evalString('{responseBody}'));
	}
	
//	checkResponse('01_Ewallet',lr.evalString('{REQUESTID}')); 
	
	lr.endTransaction('01_Ewallet', lr.AUTO);	
	
	return 0;
}

