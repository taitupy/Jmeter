//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//" Global Section       : 
//"	List of global variables and objects.
//" 
//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



//Begin Global Section

function uuidv4() {
  var dt = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (dt + Math.random()*16)%16 | 0;
        dt = Math.floor(dt/16);
        return (c=='x' ? r :(r&0x3|0x8)).toString(16);
    });
    return uuid;
}


function getCurrentDate()
{
	var currentDate = new Date();
	return currentDate.getTime();
}


function getResponeStatusCode()
{
	
	web.regSaveParamRegexp(
		{
			paramName: "responseHeader",
			regExp: 'HTTP/1.1\ (.*?)\ ',
			group: 0,
			notFound: "warning",
			scope: "headers"
		}
	);
	
	web.regSaveParamRegexp(
		{
			paramName: "responseBody",
			regExp: '(?s).+',
			group: 0,
			notFound: "warning",
			scope: "body"
		}
	);
	
}


function generateString(length) 
{
   	var str = lr.evalString('{DATE}');
	var res = str.replace(".","");
   	return res;
}

function checkResponse(stepName, responseHeader) 
{
	
	var httpDownloadTime = web.getIntProperty(web.HTTP_INFO_DOWNLOAD_TIME);
	
	//var responseHeader =  lr.evalString("{responseHeader}");
	
	// SESSION TIMEOUT
	if (httpDownloadTime >= '3000000') 
	{
		lr.message(responseHeader);
		lr.message(responseBody);
		lr.errorMessage('Time out: ' + httpDownloadTime + ' miliseconds');
		lr.endTransaction(stepName, lr.FAIL);
		lr.exit(lr.EXIT_ITERATION_AND_CONTINUE, lr.FAIL);
	}
	
	
	//var HttpReturnCode = responseHeader.split('\n')[0];
	
	if (responseHeader.indexOf("200") == -1)
	{
		lr.errorMessage('Step: ' + stepName + - ' Response: ' + responseHeader);
		lr.endTransaction(stepName, lr.FAIL);
  		lr.exit(lr.EXIT_ITERATION_AND_CONTINUE, lr.FAIL);
	}
	
	
	else
	{
		var resultCode = resultParam.length == 0 ? '' : lr.evalString('{'+ resultParam +'}');
		switch (resultCode) 
		{
			case '00':
				break;
			default:
				lr.errorMessage('ResponseBody: Step ' + stepName + ' FAILED \n' + '\nRequest: ' + request + 'Phone: ' + Phone +  ' \nResponseCode: ' +  resultCode  + ' \nResponseBody: \n' + responseBody);
				lr.endTransaction(stepName, lr.FAIL);
				lr.exit(lr.EXIT_ITERATION_AND_CONTINUE, lr.FAIL);
		}
		
	}

	

	
	
}